// Set this to your repo name for GitHub Pages project sites
// (https://<user>.github.io/cobbletoolkit/). Leave both empty if this
// deploys to a user/org root page (https://<user>.github.io/) or a
// custom domain instead.
const repoName = "CobbleToolkit";

// In dev, skip the basePath entirely rather than redirecting — `next dev`
// doesn't do a static export, so there's no GitHub Pages subpath to match,
// and this way `localhost:3000/` just serves the app directly instead of
// 404ing (the old behavior: dev required visiting `/CobbleToolkit/`, the
// production-only basePath, just to see the app). Production/export builds
// are unaffected — NODE_ENV is "production" for both `next build` and the
// static export, so the real basePath is still applied there.
// NEXT_PUBLIC_BASE_PATH still overrides both, for custom deploy targets.
const isDev = process.env.NODE_ENV !== "production";
const basePath =
  process.env.NEXT_PUBLIC_BASE_PATH ?? (isDev ? "" : `/${repoName}`);

/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "export",
  trailingSlash: true,
  basePath,
  assetPrefix: basePath ? `${basePath}/` : undefined,
  env: {
    NEXT_PUBLIC_BASE_PATH: basePath,
  },
  images: {
    unoptimized: true,
    remotePatterns: [
      {
        protocol: "https",
        hostname: "raw.githubusercontent.com",
        port: "",
        pathname: "/PokeAPI/sprites/**",
      },
    ],
  },
};

export default nextConfig;
